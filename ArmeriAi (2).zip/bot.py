import asyncio
import logging
import random
import string
from aiogram import Bot, Dispatcher, F, Router
from aiogram.filters import CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    Message,
    ReplyKeyboardMarkup,
)

# Токен вашего бота (получить у @BotFather)
TOKEN = "8984487324:AAEARkx-9bhULmDLp8nHItKGm8MqSxzgl2I"

# Администраторский юзернейм (без символа @)
ADMIN_USERNAME = "LovePepku"

# Инициализация бота и диспетчера
bot = Bot(token=TOKEN)
dp = Dispatcher(storage=MemoryStorage())
router = Router()
dp.include_router(router)

# Хранилище данных в памяти (для прод-версии лучше использовать SQLite/PostgreSQL)
# Формат users: {user_id: {"username": str, "balance": int}}
users = {}
# Формат promocodes: {code_string: amount}
promocodes = {}


# Определяем состояния FSM
class BotStates(StatesGroup):
    waiting_for_promo_code = State()  # Ожидание ввода промокода пользователем
    waiting_for_amount = State()  # Ожидание ввода суммы администратором
    waiting_for_custom_code = State()  # Ожидание ввода кастомного промокода


# Главная клавиатура
def get_main_keyboard():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="🎫Промокод"), KeyboardButton(text="👨‍🦱Профиль")],
            [KeyboardButton(text="✅Подписка")],
        ],
        resize_keyboard=True,
    )


# Функция получения/создания профиля пользователя
def get_user_data(user_id: int, username: str | None):
    if user_id not in users:
        users[user_id] = {
            "username": username or "Не указано",
            "balance": 0,
        }
    else:
        if username:
            users[user_id]["username"] = username
    return users[user_id]


# Вспомогательная функция генерации случайного промокода (формат GyhF-7Hjll)
def generate_random_code() -> str:
    part1 = "".join(random.choices(string.ascii_letters, k=4))
    part2 = "".join(random.choices(string.ascii_letters + string.digits, k=5))
    return f"{part1}-{part2}"


# --- Хэндлеры ---


# Команда /start
@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext):
    await state.clear()
    get_user_data(message.from_user.id, message.from_user.username)
    await message.answer(
        "Привет! Я Armeri AITG выбирай пункт!", reply_markup=get_main_keyboard()
    )


# Кнопка "✅Подписка"
@router.message(F.text == "✅Подписка")
async def btn_subscription(message: Message):
    await message.answer("Функция в разработке")


# Кнопка "👨‍🦱Профиль"
@router.message(F.text == "👨‍🦱Профиль")
async def btn_profile(message: Message):
    user = get_user_data(message.from_user.id, message.from_user.username)
    user_name_display = (
        f"@{user['username']}"
        if user["username"] != "Не указано"
        else message.from_user.full_name
    )

    text = f"🪪Имя пользователя: {user_name_display}\n💵Баланс: {user['balance']} руб."

    # Проверка, является ли пользователь @LovePepku
    if (
        message.from_user.username
        and message.from_user.username.lower() == ADMIN_USERNAME.lower()
    ):
        kb = InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text="Создать Промокод", callback_data="admin_create_promo"
                    )
                ]
            ]
        )
        await message.answer(text, reply_markup=kb)
    else:
        await message.answer(text)


# Кнопка "🎫Промокод"
@router.message(F.text == "🎫Промокод")
async def btn_promo(message: Message, state: FSMContext):
    await state.set_state(BotStates.waiting_for_promo_code)
    await message.answer("Введите промокод")


# Обработка ввода промокода пользователем
@router.message(BotStates.waiting_for_promo_code)
async def process_use_promo(message: Message, state: FSMContext):
    code_entered = message.text.strip()
    user_id = message.from_user.id
    user = get_user_data(user_id, message.from_user.username)

    if code_entered in promocodes:
        reward = promocodes.pop(code_entered)
        user["balance"] += reward
        await message.answer(
            f"🎉 Промокод успешно активирован!\nВам начислено: {reward} руб.\nВаш баланс: {user['balance']} руб."
        )
    else:
        await message.answer(
            "❌ Промокод не найден, либо он уже был использован."
        )

    await state.clear()


# --- Админ-панель для создания промокодов (@LovePepku) ---


@router.callback_query(F.data == "admin_create_promo")
async def start_create_promo(callback: CallbackQuery):
    if (
        not callback.from_user.username
        or callback.from_user.username.lower() != ADMIN_USERNAME.lower()
    ):
        await callback.answer("У вас нет доступа к этой функции.", show_alert=True)
        return

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="На деньги", callback_data="promo_type_money"
                )
            ]
        ]
    )
    await callback.message.answer("На что промокод", reply_markup=kb)
    await callback.answer()


@router.callback_query(F.data == "promo_type_money")
async def promo_type_money(callback: CallbackQuery, state: FSMContext):
    await state.set_state(BotStates.waiting_for_amount)
    await callback.message.answer("Введите количество денег (от 1 до 10000 руб.):")
    await callback.answer()


@router.message(BotStates.waiting_for_amount)
async def process_amount(message: Message, state: FSMContext):
    if not message.text.isdigit():
        await message.answer("Пожалуйста, введите число от 1 до 10000.")
        return

    amount = int(message.text)
    if not (1 <= amount <= 10000):
        await message.answer("Сумма должна быть от 1 до 10000 рублей. Попробуйте снова:")
        return

    await state.update_data(promo_amount=amount)

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="Кастомный", callback_data="promo_mode_custom"
                ),
                InlineKeyboardButton(
                    text="Рандом", callback_data="promo_mode_random"
                ),
            ]
        ]
    )
    await message.answer("Какой Промокод", reply_markup=kb)


@router.callback_query(F.data == "promo_mode_random")
async def promo_mode_random(callback: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    amount = data.get("promo_amount")

    code = generate_random_code()
    promocodes[code] = amount

    await callback.message.answer(
        f"✅ Случайный промокод создан!\n\nКод: `{code}`\nНоминал: {amount} руб.",
        parse_mode="Markdown",
    )
    await state.clear()
    await callback.answer()


@router.callback_query(F.data == "promo_mode_custom")
async def promo_mode_custom(callback: CallbackQuery, state: FSMContext):
    await state.set_state(BotStates.waiting_for_custom_code)
    await callback.message.answer("Введите промокод")
    await callback.answer()


@router.message(BotStates.waiting_for_custom_code)
async def process_custom_code(message: Message, state: FSMContext):
    code = message.text.strip()
    data = await state.get_data()
    amount = data.get("promo_amount")

    if not code:
        await message.answer("Промокод не может быть пустым. Введите промокод:")
        return

    promocodes[code] = amount

    await callback_or_message_answer = message.answer(
        f"✅ Промокод `{code}` на {amount} руб. успешно создан!",
        parse_mode="Markdown",
    )
    await state.clear()


# Запуск бота
async def main():
    logging.basicConfig(level=logging.INFO)
    print("Бот запущен...")
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())